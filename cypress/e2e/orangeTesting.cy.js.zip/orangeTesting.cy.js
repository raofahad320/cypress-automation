

describe('Orange Testing Website - Automation Suite', () => {

  beforeEach(() => {
    cy.visit('https://orangetesting.com/')
  })

  //  TC-01 Easy
  it('TC-01: Verify Home Page Loads Successfully', () => {
    cy.url().should('include', 'orangetesting')
    cy.get('body').should('be.visible')
  })










  //  TC-02 Easy 
  it('TC-02: Verify Logo Image is Visible', () => {
    cy.get('img')
      .first()
      .should('be.visible')
  })










//  TC-03: Verify Orange Cloud Lab link navigates correctly
it('TC-03: Verify Orange Cloud Lab link navigates correctly', () => {

  cy.contains('Orange Cloud Lab', { matchCase: false })
    .click({ force: true })

 
  cy.url().should('include', '#orange-cloud-lab')

  cy.get('#orange-cloud-lab')
    .scrollIntoView()

  cy.get('#orange-cloud-lab')
    .should('exist')
})







  //  TC-04 Medium 
  it('TC-04: Verify Footer Section is Visible', () => {
    cy.get('footer')
      .scrollIntoView()
      .should('be.visible')
  })




})